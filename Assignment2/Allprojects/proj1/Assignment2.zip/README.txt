This project corresponds to the second Assignment of P3D.

To run the project:
-Create a new project in Visual Studio
-Import Files into the new project
-Run the program.

For a different file see the folder "assets" for the files available.
To change the file processed you need to open the file "parser.cpp".
